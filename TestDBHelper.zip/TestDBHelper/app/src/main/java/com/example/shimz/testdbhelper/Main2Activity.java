package com.example.shimz.testdbhelper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    myDbAdapter helper;
private TextView temp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        helper = new myDbAdapter(this);

        /*String[] data = helper.getLocationNamesData();
        temp = (TextView)findViewById(R.id.TextBox);
        temp.setText(data[0]);*/


    }





}
