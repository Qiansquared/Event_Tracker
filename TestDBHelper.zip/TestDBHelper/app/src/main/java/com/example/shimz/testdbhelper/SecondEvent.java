package com.example.shimz.testdbhelper;

public class SecondEvent {

}
